<?php

/* @var $this yii\web\View */

use rmrevin\yii\fontawesome\FAS;
use yii\helpers\Html;
use yii\helpers\Url;

$this->title = 'Transferências';
$this->params['breadcrumbs'][] = ['label' => 'Circulação', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
    <div class="alert alert-info config" role="alert" id="alert-saramago">
        <strong>Informação:</strong> Utilize o menu rápido para começar.
    </div>

<?php

?>