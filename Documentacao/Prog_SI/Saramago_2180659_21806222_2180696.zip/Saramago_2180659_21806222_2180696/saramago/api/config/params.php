<?php
return [

    'useHttpBasicAuth' => true,
    'useHttpBearerAuth' => true,
    'useQueryParamAuth' => true,
    'useRateLimiter' => false,

    'adminEmail' => 'admin@example.com',
];
