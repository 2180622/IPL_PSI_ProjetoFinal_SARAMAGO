<?php
return [
    [
	'codBarras' => '521359874',
        'nome' => 'Andre Machado',
        'nif' => '269745013',
        'docId' => '30315990',
        'dataNasc' => '2000-01-01',
        'morada' => 'Rua',
        'localidade' => 'Leiria',
        'codPostal' => '2400135',
	'telemovel' => '915992201',
	'Biblioteca_id' => '1',
	'TipoLeitor_id' => '1',
	'user_id' => '1',
    ],
];