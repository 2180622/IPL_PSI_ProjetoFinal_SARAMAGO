<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'SARAMAGO API';
?>
<div class="site-index">
    <?=Html::img('@web/res/logo-saramago.png', ['class'=>'logo-saramago','height'=>'70‰', 'alt'=>'SARAMAGO']) ?>
</div>
