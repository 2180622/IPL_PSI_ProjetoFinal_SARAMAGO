1 - Correr Saramago_DB.sql

2 - yii migrate --migrationPath=@yii/rbac/migrations

3 - yii migrate

4 - Correr DEMO_VALUES.sql
 

username, password:

admin
adminsaramago



